<template>
    <input type="number" v-model.number="quantity" min='1'>
</template>

<script>
export default {
    name: 'countComponent',
    data() {
        return {
            quantity: 1,
            price: 300
        }
    },
    computed: {
        total() {
            return this.quantity * this.price;
        }
    }
}
</script>