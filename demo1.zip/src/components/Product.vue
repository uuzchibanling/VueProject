<template>
    <div>
      <input type="number" v-model.number="quantity" min="1" />
      <p>单价{{ price }}</p>
      <p>购买：{{ quantity }}件</p>
      <p>总计：{{ totalPrice }}元</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ProductComponent',
    data() {
      return {
        quantity: 1,
        price: 9998
      }
    },
    computed: {
      totalPrice() {
        return this.quantity * this.price;
      }
    }
  }
  </script>
  
  <style>
  input {
    width: 50px;
    text-align: center;
  }
  </style>
  