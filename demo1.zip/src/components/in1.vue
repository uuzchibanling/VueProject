<template>
    <div>
        <h1>冲击钻</h1>
        <img alt="Vue logo" src="../assets/ooc.jpg">
        <button>ooc</button>
    </div>
</template>

<script>
export default {
    name: 'in1Component',
    components: {
        
    }
}
</script>


<style scoped>
img {
    width: 400px;
    height: 400px;
}
</style>