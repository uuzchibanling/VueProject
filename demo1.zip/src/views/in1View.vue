<template>
    <div class="in1">
        <in-1 />
    </div>
</template>

<script>
import in1 from '@/components/in1.vue';

export default {
    name: 'in1View',
    components: {
        in1
    }
}
</script>