<template>
    <div>
        <product-vue />
    </div>
</template>

<script>
import ProductVue from '@/components/Product.vue'

export default {
    name: 'oocView',
    components: {
        ProductVue
    }
}
</script>